////////////////////////
/// Made by Team AOF ///
////////////////////////

events.listen("rei.information", function (event) {

  event.add("minecraft:stone", ['Line 1', 'Line 2'])


});
